### rmotr.com
# Reading Data with Python and Pandas

This material is created for our [Reading Data with Python and Pandas Course](https://rmotr.com/rdp)