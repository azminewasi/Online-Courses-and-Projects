def test_blue_eyed_people_1():
    assert blue_eyed_people_df.shape == (3,16)
