def test_starwars_people_2():
    assert starwars_people_df.iloc[1]['height'] == '167'
