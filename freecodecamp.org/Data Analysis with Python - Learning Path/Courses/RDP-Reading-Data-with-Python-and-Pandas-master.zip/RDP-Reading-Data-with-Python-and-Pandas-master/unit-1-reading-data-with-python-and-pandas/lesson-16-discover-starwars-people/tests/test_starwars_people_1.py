def test_starwars_people_1():
    assert starwars_people_df.shape == (10,16)
