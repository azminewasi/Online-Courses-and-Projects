def test_shape():
    assert artists.shape == (5, 3)
