def test_artists():
    assert artists.iloc[3]['genre'] == 'Impressionism'
