def test_playstore_2():
    assert playstore_df.iloc[3]['App'] == 'Sketch - Draw & Paint'