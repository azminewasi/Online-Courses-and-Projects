def test_content_id_1():
    assert content_id_df.shape == (250,1)