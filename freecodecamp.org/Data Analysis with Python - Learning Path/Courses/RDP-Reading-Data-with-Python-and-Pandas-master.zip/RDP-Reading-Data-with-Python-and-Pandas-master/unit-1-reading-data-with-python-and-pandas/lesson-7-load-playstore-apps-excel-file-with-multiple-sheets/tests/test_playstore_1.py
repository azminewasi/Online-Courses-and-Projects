def test_playstore_1():
    assert playstore_df.shape == (250,9)
