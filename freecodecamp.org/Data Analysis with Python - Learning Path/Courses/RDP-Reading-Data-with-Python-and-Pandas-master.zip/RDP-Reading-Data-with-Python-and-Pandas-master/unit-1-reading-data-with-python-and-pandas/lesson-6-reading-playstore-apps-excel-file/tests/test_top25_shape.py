def test_top25_shape():
    assert playstore_df.shape == (25, 5)
