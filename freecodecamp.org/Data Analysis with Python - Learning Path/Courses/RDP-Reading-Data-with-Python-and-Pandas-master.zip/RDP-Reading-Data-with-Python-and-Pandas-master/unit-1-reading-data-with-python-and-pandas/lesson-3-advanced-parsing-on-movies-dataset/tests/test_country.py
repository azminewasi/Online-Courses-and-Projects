def test_country():
    assert '?' not in movies.country.unique()