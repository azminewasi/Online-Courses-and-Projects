def test_shape():
    assert movies.shape == (100, 12)
