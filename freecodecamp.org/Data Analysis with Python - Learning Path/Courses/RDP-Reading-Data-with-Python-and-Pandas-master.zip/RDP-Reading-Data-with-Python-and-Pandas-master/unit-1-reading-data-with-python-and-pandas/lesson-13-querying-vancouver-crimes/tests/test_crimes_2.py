def test_crimes_2():
    assert van_crimes_df.loc[3, 'DAY'] == 12.0
