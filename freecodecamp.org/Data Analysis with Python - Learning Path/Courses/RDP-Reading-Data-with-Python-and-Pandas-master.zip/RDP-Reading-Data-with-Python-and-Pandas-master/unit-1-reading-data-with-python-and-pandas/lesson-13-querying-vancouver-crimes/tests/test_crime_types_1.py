def test_crime_types_1():
    assert crime_types_count.shape == (4,)