def test_crime_types_3():
    assert crime_types_count[1] == 15
