def test_crime_types_2():
    assert crime_types_count.sum() == 64
