def test_fifa_2():
    assert fifa_df.loc[:,'Age'].sum() == 746
