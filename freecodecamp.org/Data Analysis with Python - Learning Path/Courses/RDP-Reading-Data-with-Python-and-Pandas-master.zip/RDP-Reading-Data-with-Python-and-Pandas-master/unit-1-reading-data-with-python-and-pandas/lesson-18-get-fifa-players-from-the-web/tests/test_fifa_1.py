def test_fifa_1():
    assert fifa_df.shape == (30, 5)
