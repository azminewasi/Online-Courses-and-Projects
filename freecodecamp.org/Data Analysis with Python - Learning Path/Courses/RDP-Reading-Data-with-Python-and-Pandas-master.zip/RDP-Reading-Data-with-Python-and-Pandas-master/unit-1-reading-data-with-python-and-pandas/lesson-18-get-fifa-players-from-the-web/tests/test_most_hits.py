def test_most_hits():
    assert most_hits_player['Name'][0] == 'Erling Braut  Håland'
