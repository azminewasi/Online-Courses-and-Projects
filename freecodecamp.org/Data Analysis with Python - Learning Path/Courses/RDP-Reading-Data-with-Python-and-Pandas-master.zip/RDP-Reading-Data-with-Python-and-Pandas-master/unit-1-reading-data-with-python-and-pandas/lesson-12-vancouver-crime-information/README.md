# Vancouver crime information

Using the given sqlite3 connection:
- Store all the crimes committed after 18:00 h in a `late_crimes` variable.
- Store the number of crimes committed on the month with most crimes in a `dangerous_month_crimes` variable.
