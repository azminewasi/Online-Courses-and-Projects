def test_dangerous_month_2():
    assert dangerous_month_crimes.index[0] == 6
