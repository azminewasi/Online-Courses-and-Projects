def test_crimes_1():
    assert van_crimes_df.shape == (126, 10)
