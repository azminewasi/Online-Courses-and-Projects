def test_late_crimes_1():
    assert late_crimes.shape == (57, 10)
