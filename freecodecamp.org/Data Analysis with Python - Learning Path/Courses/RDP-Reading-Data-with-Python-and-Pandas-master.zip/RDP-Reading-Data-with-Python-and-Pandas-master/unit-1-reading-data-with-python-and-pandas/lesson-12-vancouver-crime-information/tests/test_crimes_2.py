def test_crimes_2():
    assert van_crimes_df.loc[14, 'HOUR'] == 23
