def test_dangerous_month_1():
    assert dangerous_month_crimes.values[0] == 17
