def test_late_crimes_2():
    assert late_crimes.loc[7, 'HOUR'] == 20