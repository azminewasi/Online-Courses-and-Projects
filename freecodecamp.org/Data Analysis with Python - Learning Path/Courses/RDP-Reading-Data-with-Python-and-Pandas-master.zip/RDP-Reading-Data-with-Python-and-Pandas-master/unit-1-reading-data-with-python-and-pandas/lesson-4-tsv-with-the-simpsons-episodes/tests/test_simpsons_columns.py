def test_simpsons_columns():
    assert list(simpsons.columns) == ['Title', 'Air date', 'IMDB rating']
