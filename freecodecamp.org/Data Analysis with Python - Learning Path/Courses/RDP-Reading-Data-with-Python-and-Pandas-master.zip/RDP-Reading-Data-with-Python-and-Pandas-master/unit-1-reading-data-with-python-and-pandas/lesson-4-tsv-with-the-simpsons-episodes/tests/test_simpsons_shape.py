def test_simpsons_shape():
    assert simpsons.shape == (597, 3)
