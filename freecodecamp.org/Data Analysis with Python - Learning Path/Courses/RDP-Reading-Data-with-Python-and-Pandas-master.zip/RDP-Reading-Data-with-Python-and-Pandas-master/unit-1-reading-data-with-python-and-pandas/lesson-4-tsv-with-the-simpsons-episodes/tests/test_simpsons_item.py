def test_simpsons_item():
    assert simpsons.iloc[234, 2] == 6.6
