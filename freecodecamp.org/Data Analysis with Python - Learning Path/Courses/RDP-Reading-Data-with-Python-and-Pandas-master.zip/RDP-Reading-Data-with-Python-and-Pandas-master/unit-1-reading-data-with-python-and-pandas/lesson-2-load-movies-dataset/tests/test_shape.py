def test_shape():
    assert movies.shape == (97, 13)
