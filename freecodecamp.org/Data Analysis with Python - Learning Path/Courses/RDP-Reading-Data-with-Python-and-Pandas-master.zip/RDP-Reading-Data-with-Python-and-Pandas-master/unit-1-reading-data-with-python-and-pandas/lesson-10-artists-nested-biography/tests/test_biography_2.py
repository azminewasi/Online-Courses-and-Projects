def test_biography_2():
    assert biography.iloc[4]['paintings'] == 194
