def test_artists_2():
    assert artists.iloc[2]['name'] == 'Diego Rivera'