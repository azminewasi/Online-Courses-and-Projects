def test_biography_1():
    assert biography.shape == (5,7)
