def test_artists_1():
    assert artists.shape == (5,5)