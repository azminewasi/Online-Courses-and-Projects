def test_biography_3():
    assert biography.iloc[3]['name'] == 'Claude Monet'
