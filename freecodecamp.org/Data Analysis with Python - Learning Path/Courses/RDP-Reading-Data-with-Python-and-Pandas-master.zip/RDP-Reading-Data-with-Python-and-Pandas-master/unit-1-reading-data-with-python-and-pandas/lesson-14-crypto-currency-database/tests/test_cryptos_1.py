def test_cryptos_1():
    assert crypto_df.shape == (100, 5)
