def test_weekly_change_2():
    assert weekly_change_df.iloc[4]['price_usd'] == 0.01