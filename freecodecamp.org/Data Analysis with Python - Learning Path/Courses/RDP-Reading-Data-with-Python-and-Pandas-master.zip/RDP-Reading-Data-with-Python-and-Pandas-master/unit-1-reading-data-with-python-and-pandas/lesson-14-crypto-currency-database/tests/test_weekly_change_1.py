def test_weekly_change_1():
    assert weekly_change_df.iloc[0]['coin_name'] == 'DxChain Token'
