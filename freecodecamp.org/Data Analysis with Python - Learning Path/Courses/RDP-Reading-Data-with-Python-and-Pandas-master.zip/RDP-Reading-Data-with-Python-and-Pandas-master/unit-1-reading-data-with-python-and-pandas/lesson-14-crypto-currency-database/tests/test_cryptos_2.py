def test_cryptos_2():
    assert crypto_df.loc[12, 'symbol'] == 'LINK'